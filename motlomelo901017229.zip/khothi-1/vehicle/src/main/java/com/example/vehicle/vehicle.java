package com.example.vehicle;

public class vehicle {
    public int getVehicleId() {
        return 0;
    }
}
